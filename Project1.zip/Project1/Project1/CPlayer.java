import java.util.*;
public class CPlayer {

Random r = new Random();
int player1Starts = r.nextInt(2);
public void CPlayer()
{

}

public void select()
{
   Scanner userIn = new Scanner(System.in);
   System.out.println("Select a domino to start using a domino from your hand. Check the table for the IDs of each domino");
   
   String choice = userIn.nextLine();
   
   if(player1Starts == 1)
   {
   
   }   
}

}