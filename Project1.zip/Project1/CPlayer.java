public class CPlayer {

}