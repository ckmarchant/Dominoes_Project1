public class CTable{

}