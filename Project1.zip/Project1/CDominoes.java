public class CDominoes {

}