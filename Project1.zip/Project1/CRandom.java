public class CRandom{


}